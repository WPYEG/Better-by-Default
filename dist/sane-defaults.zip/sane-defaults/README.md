# Better by Default

Sane defaults for every new WordPress site — the installable plugin.

Every policy is individually toggleable under **Settings → Better by Default**, and the whole
thing is built around one idea worth carrying home:

> A "default" is just an opinionated `add_filter()` sitting behind a toggle.

## Install

1. Copy the `sane-defaults` folder into `wp-content/plugins/`
   (or upload the zip via **Plugins → Add New → Upload Plugin**).
2. Activate. On activation the documented defaults are seeded automatically.
3. Visit **Settings → Better by Default** to flip switches.

WP-CLI:

```bash
wp plugin install ./sane-defaults.zip --activate
```

For production you can also drop the main PHP file into `wp-content/mu-plugins/` so the
policy survives theme changes and can't be deactivated — though you lose the settings screen
convenience when loaded that way.

## How it's built

The whole map lives in one array: `wpyeg_defaults_schema()`. Read that first. Each entry
defines a key, its default, its type (`toggle` / `select` / `number`), and its group. The
bootstrap function then wires each *enabled* policy to its WordPress hook. The `wpyeg_`
option prefix is kept deliberately as the WPYEG org convention.

Settings-screen convention: toggle rows place the descriptive schema label immediately after
the checkbox inside one clickable label; they never use a generic `Enabled` label. Select and
number fields retain descriptive row labels. Every control connects its help text with
`aria-describedby`. Labels and descriptions inherit WordPress's classic `form-table` styles;
do not add custom typography. Help text may contain attribute-free `<code>` only, sanitized
through `wp_kses()`, for machine-facing identifiers. It may also contain an `<a>` with only an
`href` when an external claim benefits from a direct authoritative reference. Name the specific
publication or directive and section when one exists; do not use vague attributions such as
"per NIST." Keep that pattern when adding settings.

Defaults on out of the box: restrict REST user discovery, lock down XML-RPC by category
(incoming pingbacks off, remote publishing off, system.multicall refused), require strong
passwords (15+ chars, breach-screened, no forced composition), limit `unfiltered_html` to
administrators, send baseline security headers,
set `X-Frame-Options: SAMEORIGIN`, disable AI connectors, disable comments/pingbacks/self-pingbacks,
disable author archives, redirect attachment pages, disable emojis, right-size login sessions in
days (a 2-day regular login, 14 days when remembered, floored so ticking "Remember Me" can never
shorten a session), and install core maintenance/security releases automatically while holding
major releases for testing. Translation files retain WordPress's existing automatic-update behaviour.

Off by default (opt-in, because they change behaviour): require-auth-for-all-REST, prohibit
Application Passwords (left available by default — the safer, revocable REST credential),
block the XML-RPC endpoint entirely, title-only admin search, remove/unlink/replace the login
logo (the WordPress logo is kept by default), hide the front-end admin bar, hide the editor's
post-password option, force the classic editor, lowercase upload filenames, show the generated
image sizes on the attachment screen, disable Remember Me,
throttle Heartbeat, and remove the version fingerprint — that last one because it
is obscurity, not hardening: it trims scanner noise but does not make an out-of-date site safer.

Plugin and theme code updates keep using WordPress's per-item auto-update choices. The plugin
does not infer safety from version numbers. An explicit `WP_AUTO_UPDATE_CORE`,
`AUTOMATIC_UPDATER_DISABLED`, or `DISALLOW_FILE_MODS` policy remains operator-owned and is
reported on the settings screen rather than silently overridden.

XML-RPC is an aging API, not a backdoor. Pingbacks are the strongest reason for the locked-down
default; refusing `system.multicall` is modest defence-in-depth against batching, not a password
control — WordPress 4.4 prevented it from being used as a password-guessing multiplier. Keep the endpoint and
Remote Publishing available when Jetpack needs them, and test connected features after changing
method controls. Application Passwords inherit the owning user's capabilities, so integrations
should use a least-privileged account.

## Three things this plugin can't do for you

These live in `wp-config.php`, above the plugin layer:

```php
define( 'DISALLOW_FILE_EDIT', true );  // no in-dashboard code editor
define( 'AUTOSAVE_INTERVAL', 120 );    // gentler autosave
define( 'WP_POST_REVISIONS', 10 );     // cap revision bloat
```

## License

GPL-3.0-or-later. Fork it, teach with it, ship it.
